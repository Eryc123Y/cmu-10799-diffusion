"""
U-Net Architecture for Diffusion Models

In this file, you should implements a U-Net architecture suitable for DDPM.

Architecture Overview:
    Input: (batch_size, channels, H, W), timestep
    
    Encoder (Downsampling path)

    Middle
    
    Decoder (Upsampling path)
    
    Output: (batch_size, channels, H, W)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Tuple

from .blocks import (
    TimestepEmbedding,
    ResBlock,
    AttentionBlock,
    Downsample,
    Upsample,
    GroupNorm32,
)


class UNet(nn.Module):
    """
    Timestep-conditioned U-Net for DDPM noise prediction.

    Args:
        in_channels: Number of input image channels (3 for RGB)
        out_channels: Number of output channels (3 for RGB)
        base_channels: Base channel count (multiplied by channel_mult at each level)
        channel_mult: Tuple of channel multipliers for each resolution level
                     e.g., (1, 2, 4, 8) means channels are [C, 2C, 4C, 8C]
        num_res_blocks: Number of residual blocks per resolution level
        attention_resolutions: Resolutions at which to apply self-attention
                              e.g., [16, 8] applies attention at 16x16 and 8x8
        num_heads: Number of attention heads
        dropout: Dropout probability
        use_scale_shift_norm: Whether to use FiLM conditioning in ResBlocks
    
    Example:
        >>> model = UNet(
        ...     in_channels=3,
        ...     out_channels=3, 
        ...     base_channels=128,
        ...     channel_mult=(1, 2, 2, 4),
        ...     num_res_blocks=2,
        ...     attention_resolutions=[16, 8],
        ... )
        >>> x = torch.randn(4, 3, 64, 64)
        >>> t = torch.randint(0, 1000, (4,))
        >>> out = model(x, t)
        >>> out.shape
        torch.Size([4, 3, 64, 64])
    """
    
    def __init__(
        self,
        in_channels: int = 3,
        out_channels: int = 3,
        base_channels: int = 128,
        channel_mult: Tuple[int, ...] = (1, 2, 2, 4),
        num_res_blocks: int = 2,
        attention_resolutions: List[int] = [16, 8],
        num_heads: int = 4,
        dropout: float = 0.1,
        use_scale_shift_norm: bool = True,
        image_size: int = 64,
    ):
        super().__init__()
        
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.base_channels = base_channels
        self.channel_mult = channel_mult
        self.num_res_blocks = num_res_blocks
        self.attention_resolutions = attention_resolutions
        self.num_heads = num_heads
        self.dropout = dropout
        self.use_scale_shift_norm = use_scale_shift_norm
        self.image_size = image_size

        time_embed_dim = base_channels * 4
        self.time_embedding = TimestepEmbedding(time_embed_dim)

        self.input_conv = nn.Conv2d(
            in_channels,
            base_channels,
            kernel_size=3,
            padding=1,
        )

        self.down_blocks = nn.ModuleList()
        self.up_blocks = nn.ModuleList()
        self.skip_channels: list[int] = []

        current_channels = base_channels
        current_resolution = image_size

        for level, mult in enumerate(channel_mult):
            out_channels_for_level = base_channels * mult

            for _ in range(num_res_blocks):
                block = self._make_res_attention_block(
                    in_channels=current_channels,
                    out_channels=out_channels_for_level,
                    time_embed_dim=time_embed_dim,
                    current_resolution=current_resolution,
                )
                self.down_blocks.append(block)
                current_channels = out_channels_for_level
                self.skip_channels.append(current_channels)

            if level != len(channel_mult) - 1:
                self.down_blocks.append(Downsample(current_channels))
                current_resolution = current_resolution // 2

        self.middle_block1 = ResBlock(
            current_channels,
            current_channels,
            time_embed_dim,
            dropout=dropout,
            use_scale_shift_norm=use_scale_shift_norm,
        )
        self.middle_attention = AttentionBlock(current_channels, num_heads=num_heads)
        self.middle_block2 = ResBlock(
            current_channels,
            current_channels,
            time_embed_dim,
            dropout=dropout,
            use_scale_shift_norm=use_scale_shift_norm,
        )

        for level, mult in reversed(list(enumerate(channel_mult))):
            out_channels_for_level = base_channels * mult

            for _ in range(num_res_blocks):
                skip_channels = self.skip_channels.pop()
                block = self._make_res_attention_block(
                    in_channels=current_channels + skip_channels,
                    out_channels=out_channels_for_level,
                    time_embed_dim=time_embed_dim,
                    current_resolution=current_resolution,
                )
                self.up_blocks.append(block)
                current_channels = out_channels_for_level

            if level != 0:
                self.up_blocks.append(Upsample(current_channels))
                current_resolution = current_resolution * 2

        self.output_norm = GroupNorm32(32, current_channels)
        self.output_conv = nn.Conv2d(
            current_channels,
            out_channels,
            kernel_size=3,
            padding=1,
        )

    def _make_res_attention_block(
        self,
        in_channels: int,
        out_channels: int,
        time_embed_dim: int,
        current_resolution: int,
    ) -> nn.ModuleDict:
        """
        Build one residual block, plus optional attention at this resolution.
        """
        attention: nn.Module
        if current_resolution in self.attention_resolutions:
            attention = AttentionBlock(out_channels, num_heads=self.num_heads)
        else:
            attention = nn.Identity()

        return nn.ModuleDict(
            {
                "res": ResBlock(
                    in_channels,
                    out_channels,
                    time_embed_dim,
                    dropout=self.dropout,
                    use_scale_shift_norm=self.use_scale_shift_norm,
                ),
                "attn": attention,
            }
        )
    
    def forward(self, x: torch.Tensor, t: torch.Tensor) -> torch.Tensor:
        """
        Predict the DDPM target for a noisy image batch.
        
        Args:
            x: Input tensor of shape (batch_size, in_channels, height, width)
               This is typically the noisy image x_t
            t: Timestep tensor of shape (batch_size,)

        Returns:
            Output tensor of shape (batch_size, out_channels, height, width)
        """
        if t.ndim != 1:
            raise ValueError(f"Expected t to have shape (batch_size,), got {t.shape}")

        time_emb = self.time_embedding(t)

        h = self.input_conv(x)
        skip_connections: list[torch.Tensor] = []

        for block in self.down_blocks:
            if isinstance(block, Downsample):
                h = block(h)
            else:
                h = block["res"](h, time_emb)
                h = block["attn"](h)
                skip_connections.append(h)

        h = self.middle_block1(h, time_emb)
        h = self.middle_attention(h)
        h = self.middle_block2(h, time_emb)

        for block in self.up_blocks:
            if isinstance(block, Upsample):
                h = block(h)
            else:
                skip = skip_connections.pop()
                h = torch.cat([h, skip], dim=1)
                h = block["res"](h, time_emb)
                h = block["attn"](h)

        h = self.output_norm(h)
        h = F.silu(h)
        output = self.output_conv(h)

        if output.shape[2:] != x.shape[2:]:
            raise ValueError(
                f"Expected output spatial shape {x.shape[2:]}, got {output.shape[2:]}"
            )

        return output


def create_model_from_config(config: dict) -> UNet:
    """
    Factory function to create a UNet from a configuration dictionary.
    
    Args:
        config: Dictionary containing model configuration
                Expected to have a 'model' key with the relevant parameters
    
    Returns:
        Instantiated UNet model
    """
    model_config = config['model']
    data_config = config['data']
    
    return UNet(
        in_channels=data_config['channels'],
        out_channels=data_config['channels'],
        base_channels=model_config['base_channels'],
        channel_mult=tuple(model_config['channel_mult']),
        num_res_blocks=model_config['num_res_blocks'],
        attention_resolutions=model_config['attention_resolutions'],
        num_heads=model_config['num_heads'],
        dropout=model_config['dropout'],
        use_scale_shift_norm=model_config['use_scale_shift_norm'],
        image_size=data_config['image_size'],
    )


# =============================================================================
# Testing
# =============================================================================

if __name__ == "__main__":
    # Test the model
    print("Testing UNet...")
    
    model = UNet(
        in_channels=3,
        out_channels=3,
        base_channels=128,
        channel_mult=(1, 2, 2, 4),
        num_res_blocks=2,
        attention_resolutions=[16, 8],
        num_heads=4,
        dropout=0.1,
    )
    
    # Count parameters
    num_params = sum(p.numel() for p in model.parameters())
    print(f"Number of parameters: {num_params:,} ({num_params / 1e6:.2f}M)")
    
    # Test forward pass
    batch_size = 4
    x = torch.randn(batch_size, 3, 64, 64)
    t = torch.rand(batch_size)
    
    with torch.no_grad():
        out = model(x, t)
    
    print(f"Input shape: {x.shape}")
    print(f"Output shape: {out.shape}")
    print("✓ Forward pass successful!")
